# Insert all the different paddles here
def readPaddle():
    if paddleChoice is 1:
        selectedPaddle = paddle1
        return
    if paddleChoice is 2:
        selectedPaddle = paddle2
        return
# Insert all the ball choices here
def readBall():
    if ballChoice is 1:
        selectednBall = ball1
        return